// Définition des cas et des décisions
const cases = {
    1: { 
        question: "Maintenance prioritaire ?", 
        yes: { next: 2, message: "Objectif : Rassurer le client et trouver une date. Arguments : Rassurer - système actif. Fast : Sigfox, Moonshoot : Ethernet/WiFi. Action : Proposer une date." }, 
        no: { next: 4, message: "Objectif : Rassurer le client et trouver une date. Arguments : Rassurer - système OK malgré zone dégradée. Action : Promouvoir le Self Care en priorité." }
    },
    2: { 
        question: "Client insatisfait ?", 
        yes: { next: "-", message: "Action : Transfert planning. Service planning optimise les créneaux de rdv et trouvera un créneau spécial." }, 
        no: { next: "-", message: "Terminer la conversation avec formule ESCDA." }
    },
    4: { 
        question: "Self Care fonctionne-t-il ?", 
        yes: { next: "-", message: "Action réussie. Terminer avec formule ESCDA." }, 
        no: { next: 5, message: "Caler une date lointaine et historiser une ouverture de maintenance. Terminer avec formule ESCDA." }
    },
    5: { 
        question: "Caler une date lointaine et historiser ?", 
        yes: { next: "-", message: "Action terminée avec succès." }, 
        no: { next: "-", message: "Terminer avec formule ESCDA." }
    },
    // Ajouter les autres cas ici
};

// Initialisation du nœud actuel
let currentNode = null;

// Gestionnaire d'événement pour démarrer un cas
document.getElementById("start-case").addEventListener("click", () => {
    const selectedCase = parseInt(document.getElementById("cases").value, 10); // Récupération du cas sélectionné
    currentNode = selectedCase; // Initialisation du nœud actuel
    showQuestion(); // Afficher la première question
});

// Gestionnaire pour "Oui"
document.getElementById("yes-button").addEventListener("click", () => {
    navigateTree("yes");
});

// Gestionnaire pour "Non"
document.getElementById("no-button").addEventListener("click", () => {
    navigateTree("no");
});

// Fonction pour afficher une question
function showQuestion() {
    const caseData = cases[currentNode]; // Données du cas actuel
    if (caseData) {
        document.getElementById("question").textContent = caseData.question; // Affiche la question
        document.getElementById("action-message").textContent = ""; // Efface les anciens messages
        document.getElementById("result").classList.add("hidden"); // Cache le résultat final
        document.getElementById("decision-tree").classList.remove("hidden"); // Affiche les options
    } else {
        document.getElementById("question").textContent = "Cas invalide.";
    }
}

// Fonction pour naviguer dans l'arbre
function navigateTree(response) {
    const caseData = cases[currentNode];
    const nextStep = caseData[response]; // Récupère les informations associées à la réponse
    if (nextStep.next === "-") {
        document.getElementById("result").textContent = "Fin de l'arbre. Action finalisée.";
        document.getElementById("result").classList.remove("hidden"); // Affiche le résultat
        document.getElementById("decision-tree").classList.add("hidden"); // Cache les boutons
    } else {
        currentNode = nextStep.next; // Met à jour le nœud actuel
        showQuestion(); // Affiche la question suivante
    }
    // Affiche le message associé à la réponse choisie
    document.getElementById("action-message").textContent = nextStep.message || "Pas d'information supplémentaire.";
}
